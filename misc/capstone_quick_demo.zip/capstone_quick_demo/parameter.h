//wifi ssid and password
#define SECRET_SSID "Justbit"
#define SECRET_PASS "masterjustbit"

//time interval for data collection (in seconds)
#define time_ 600
